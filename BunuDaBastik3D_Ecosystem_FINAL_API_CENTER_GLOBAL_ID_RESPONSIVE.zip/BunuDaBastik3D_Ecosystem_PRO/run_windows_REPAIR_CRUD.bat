@echo off
chcp 65001 >nul
cd /d %~dp0
if not exist logs mkdir logs
if not exist .venv (
  py -m venv .venv
)
call .venv\Scripts\activate
python -m pip install --upgrade pip
pip install -r requirements.txt
python app\repair_database.py
set BDB_SAFE_MODE=1
set BDB_DEBUG=1
python app\main_safe.py
if errorlevel 1 (
  echo.
  echo Uygulama hata verdi. Bu dosyalari bana gonder:
  echo - logs\run_final_stable_console.log
  echo - %%LOCALAPPDATA%%\BunuDaBastik3D\logs\app_debug.log
  pause
)
